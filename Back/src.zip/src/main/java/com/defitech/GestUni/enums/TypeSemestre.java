package com.defitech.GestUni.enums;

public enum TypeSemestre {
    SEMESTRE_1, SEMESTRE_2, SEMESTRE_3, SEMESTRE_4, SEMESTRE_5, SEMESTRE_6
}
