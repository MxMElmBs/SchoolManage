package com.defitech.GestUni.models.Chahib;

public enum StatutDocument {
    EN_COURS_DE_TRAITEMENT,
    TRAITE,
    EN_REDACTION
}
