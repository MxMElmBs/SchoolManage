package com.defitech.GestUni.service.Chahib;

public class DocumentSaveException extends RuntimeException {
    public DocumentSaveException(String message) {
        super(message);
    }
}
