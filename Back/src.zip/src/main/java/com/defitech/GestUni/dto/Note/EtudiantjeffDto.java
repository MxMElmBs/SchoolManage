package com.defitech.GestUni.dto.Note;

import lombok.Data;

@Data
public class EtudiantjeffDto {
    private Long id;
    private String matricule;
    private String nom;
    private String prenom;
    private String filiere;
}
