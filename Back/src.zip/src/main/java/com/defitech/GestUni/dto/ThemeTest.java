package com.defitech.GestUni.dto;

import lombok.Data;

@Data
public class ThemeTest {
    private String theme;
    }
