package com.defitech.GestUni.models.BAKA.JeffService;

import com.defitech.GestUni.dto.Note.UejeffDto;
import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.BAKA.Exception.ResourceNotFoundException;
import com.defitech.GestUni.models.BAKA.JeffRepository.UejeffRepository;
import com.defitech.GestUni.models.Bases.Filiere;
import com.defitech.GestUni.models.Bases.Professeur;
import com.defitech.GestUni.models.Bases.UE;
import com.defitech.GestUni.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UejeffService {

    @Autowired
    private UERepository ueRepository;

    @Autowired
    private UejeffRepository uejeffRepository;

    @Autowired
    private FiliereRepository filiereRepository;

    @Autowired
    private ProfesseurRepository professeurRepository;

    public UejeffDto addUe(UejeffDto uejeffDto) {
        UE ue = new UE();
        ue.setCode(uejeffDto.getCode());
        ue.setLibelle(uejeffDto.getLibelle());
        ue.setTypeUe(uejeffDto.getType());
        ue.setDescriptUe(uejeffDto.getDescription());
        ue.setCredit(uejeffDto.getCredit());
        ue.setNiveauEtude(uejeffDto.getNiveauEtude());
        ue.setTypeSemestre(uejeffDto.getTypeSemestre());

        List<Filiere> filieres = filiereRepository.findAllById(uejeffDto.getFiliereIds());
        ue.setFilieres(filieres);

        Professeur professeur = professeurRepository.findById(uejeffDto.getProfesseurId())
                .orElseThrow(() -> new RuntimeException("Professeur not found"));
        ue.setProfesseur(professeur);

        UE savedUe = ueRepository.save(ue);

        UejeffDto savedUejeffDto = new UejeffDto();
        // Mapper les champs du savedUe à savedUejeffDto
        savedUejeffDto.setCode(savedUe.getCode());
        savedUejeffDto.setLibelle(savedUe.getLibelle());
        savedUejeffDto.setType(savedUe.getTypeUe());
        savedUejeffDto.setDescription(savedUe.getDescriptUe());
        savedUejeffDto.setCredit(savedUe.getCredit());
        savedUejeffDto.setNiveauEtude(savedUe.getNiveauEtude());
        savedUejeffDto.setTypeSemestre(savedUe.getTypeSemestre());
        savedUejeffDto.setProfesseurId(professeur.getProfesseurId());
        savedUejeffDto.setProfesseurName(professeur.getNom());
        savedUejeffDto.setProfesseurPrenom(professeur.getPrenom());
        savedUejeffDto.setFiliereIds(filieres.stream().map(Filiere::getFiliereId).collect(Collectors.toList()));
        return savedUejeffDto;
    }
    //Supprimer une UE
    public void supprimerUe(Long id) {
        // Vérifie d'abord si l'UE existe
        UE ue = ueRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UE avec l'id " + id + " non trouvée."));

        // Suppression de l'UE
        ueRepository.delete(ue);
    }

    //Modifier une UE
    public UejeffDto modifierUe(Long id, UejeffDto uejeffDto) {
        // Rechercher l'UE par son id
        UE ueExistante = ueRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UE avec l'id " + id + " non trouvée."));

        // Mise à jour des champs
        ueExistante.setUeId(uejeffDto.getId());
        ueExistante.setCode(uejeffDto.getCode());
        ueExistante.setLibelle(uejeffDto.getLibelle());
        ueExistante.setTypeUe(uejeffDto.getType());
        ueExistante.setDescriptUe(uejeffDto.getDescription());
        ueExistante.setCredit(uejeffDto.getCredit());
        ueExistante.setNiveauEtude(uejeffDto.getNiveauEtude());
        ueExistante.setTypeSemestre(uejeffDto.getTypeSemestre());

        // Mise à jour des relations (Filière, Professeur, etc.)
        List<Filiere> filieres = filiereRepository.findAllById(uejeffDto.getFiliereIds());
        ueExistante.setFilieres(filieres);

        Professeur professeur = professeurRepository.findById(uejeffDto.getProfesseurId())
                .orElseThrow(() -> new ResourceNotFoundException("Professeur non trouvé"));
        ueExistante.setProfesseur(professeur);

        // Enregistrer les modifications
        UE updatedUe = ueRepository.save(ueExistante);

        // Convertir l'entité en DTO et la retourner
        UejeffDto updatedUeDto = new UejeffDto();
        updatedUeDto.setCode(updatedUe.getCode());
        updatedUeDto.setLibelle(updatedUe.getLibelle());
        updatedUeDto.setType(updatedUe.getTypeUe());
        updatedUeDto.setDescription(updatedUe.getDescriptUe());
        updatedUeDto.setCredit(updatedUe.getCredit());
        updatedUeDto.setNiveauEtude(updatedUe.getNiveauEtude());
        updatedUeDto.setTypeSemestre(updatedUe.getTypeSemestre());
        updatedUeDto.setProfesseurId(professeur.getProfesseurId());
        updatedUeDto.setProfesseurName(professeur.getNom());
        updatedUeDto.setProfesseurPrenom(professeur.getPrenom());
        updatedUeDto.setFiliereIds(filieres.stream().map(Filiere::getFiliereId).collect(Collectors.toList()));

        return updatedUeDto;
    }

    public List<UejeffDto> obtenirToutesLesUes() {
        List<UE> ues = ueRepository.findAll();
        return ues.stream().map(ue -> {
            UejeffDto dto = new UejeffDto();
            dto.setId(ue.getUeId());
            dto.setCode(ue.getCode());
            dto.setLibelle(ue.getLibelle());
            dto.setType(ue.getTypeUe());
            dto.setDescription(ue.getDescriptUe());
            dto.setCredit(ue.getCredit());
            dto.setNiveauEtude(ue.getNiveauEtude());
            dto.setTypeSemestre(ue.getTypeSemestre());
            if (ue.getFilieres() != null && !ue.getFilieres().isEmpty()) {
                List<Long> filiereIds = ue.getFilieres().stream()
                        .map(Filiere::getFiliereId)
                        .collect(Collectors.toList());
                dto.setFiliereIds(filiereIds); // Utilisation de filiereIds (liste)
            }
            dto.setProfesseurId(ue.getProfesseur().getProfesseurId());
            dto.setProfesseurName(ue.getProfesseur().getNom());
            dto.setProfesseurPrenom(ue.getProfesseur().getPrenom());
            dto.setProfesseurEmail(ue.getProfesseur().getEmail());
            return dto;
        }).collect(Collectors.toList());
    }


    public UejeffDto obtenirUeParId(Long id) {
        UE ue = ueRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UE avec l'id " + id + " non trouvée."));

        UejeffDto dto = new UejeffDto();
        dto.setCode(ue.getCode());
        dto.setLibelle(ue.getLibelle());
        dto.setType(ue.getTypeUe());
        dto.setDescription(ue.getDescriptUe());
        dto.setCredit(ue.getCredit());
        dto.setNiveauEtude(ue.getNiveauEtude());
        dto.setTypeSemestre(ue.getTypeSemestre());
        if (ue.getFilieres() != null && !ue.getFilieres().isEmpty()) {
            List<Long> filiereIds = ue.getFilieres().stream()
                    .map(Filiere::getFiliereId)
                    .collect(Collectors.toList());
            dto.setFiliereIds(filiereIds); // Utilisation de filiereIds (liste)
        }
        dto.setProfesseurId(ue.getProfesseur().getProfesseurId());
        dto.setProfesseurName(ue.getProfesseur().getNom());
        dto.setProfesseurPrenom(ue.getProfesseur().getPrenom());

        return dto;
    }

    //PAGE NOTES
    public List<UejeffDto> getUesBySemestre(TypeSemestre typeSemestre) {
        List<UE> ues = uejeffRepository.findByTypeSemestre(typeSemestre);
        return ues.stream().map(this::convertToUeDto).collect(Collectors.toList());
    }

    // Méthode pour convertir une UE en UeDto
    private UejeffDto convertToUeDto(UE ue) {
        UejeffDto dto = new UejeffDto();
        dto.setCode(ue.getCode());
        dto.setLibelle(ue.getLibelle());
        dto.setCredit(ue.getCredit());
        dto.setType(ue.getTypeUe());
        dto.setTypeSemestre(TypeSemestre.valueOf(ue.getTypeSemestre().name()));  // Assumant que tu veux afficher le type de semestre en tant que texte
        return dto;
    }


    //Méthode pour les Ue qui ont reçu les notes
    public List<UejeffDto> getUesWithNotesBySemestre(TypeSemestre typeSemestre) {
        List<UE> ues = uejeffRepository.findUesWithNotesBySemestre(typeSemestre);
        return ues.stream().map(this::convertToUenoteDto).collect(Collectors.toList());
    }
    // Méthode pour convertir une UE en UeDto
    private UejeffDto convertToUenoteDto(UE ue) {
        UejeffDto dto = new UejeffDto();
        dto.setCode(ue.getCode());
        dto.setLibelle(ue.getLibelle());
        dto.setCredit(ue.getCredit());
        dto.setType(ue.getTypeUe());
        dto.setTypeSemestre(ue.getTypeSemestre());
        return dto;
    }

}
