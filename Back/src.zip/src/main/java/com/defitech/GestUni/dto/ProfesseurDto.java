package com.defitech.GestUni.dto;

import lombok.Data;

@Data
public class ProfesseurDto {

    private Long professeurId;
    private String nom;
    private String prenom;
}
