package com.defitech.GestUni.dto.authDto;

import lombok.Data;

@Data
public class RefreshTokenRequest {

    private String refreshtoken;
}
