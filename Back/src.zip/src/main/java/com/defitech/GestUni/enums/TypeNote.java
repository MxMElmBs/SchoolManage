package com.defitech.GestUni.enums;

public enum TypeNote {
    DEVOIR, EXAMEN
}
