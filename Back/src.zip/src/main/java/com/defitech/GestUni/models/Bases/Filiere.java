package com.defitech.GestUni.models.Bases;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "filieres")
public class Filiere {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long filiereId;

    @Column(nullable = false, unique = true)
    private String nomFiliere;
    private String description;

    @ManyToOne
    @JoinColumn(name = "parcours_id", nullable = false)
    private Parcours parcours;

    @ManyToMany(mappedBy = "filieres")
    private List<UE> ue;
}
