package com.defitech.GestUni.enums;

public enum UserRole {
    ADMIN, DE, COMPTABLE, PROFESSEUR, ETUDIANT
}
