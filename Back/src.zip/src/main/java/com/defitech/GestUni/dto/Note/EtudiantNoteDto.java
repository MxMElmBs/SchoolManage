package com.defitech.GestUni.dto.Note;

import lombok.Data;

@Data
public class EtudiantNoteDto {
    private Long etudiantId;
    private float note;
}
