package com.defitech.GestUni.models.Chahib;

import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.Filiere;
import com.defitech.GestUni.models.Bases.Parcours;
import com.defitech.GestUni.models.Bases.Professeur;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String theme;
    private LocalDateTime createdAt;

    @Lob  // Annotation pour supporter de grandes quantités de texte
    @Column(columnDefinition = "LONGTEXT")  // Spécifie explicitement le type LONGTEXT dans MySQL
    private String introduction;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String resume_dia_classe;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String resume_dia_sequence;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String resumeDoc;

    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String conclusion;

    private String documentUrl;

    @Enumerated(EnumType.STRING)
    private TypeDocument typeDocument;

    @Enumerated(EnumType.STRING)
    private StatutDocument statut;

    @ManyToOne
    @JoinColumn(name = "professeur_id")
    private Professeur professeur;

    @ManyToOne
    @JoinColumn(name = "etudiant_id", referencedColumnName = "etudiantId")
    private Etudiant etudiant;

    @ManyToOne
    @JoinColumn(name = "filiere_id")
    private Filiere filiere;

    @ManyToOne
    @JoinColumn(name = "parcours_id")
    private Parcours parcours;

}
