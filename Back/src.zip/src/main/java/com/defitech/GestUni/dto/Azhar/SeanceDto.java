package com.defitech.GestUni.dto.Azhar;

import lombok.Data;

import java.time.LocalTime;

@Data
public class SeanceDto {
    private LocalTime startTime;
    private LocalTime endTime;
}
