package com.defitech.GestUni.models.BAKA;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class EmailjeffConfig {

    // Getters pour les propriétés
    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private String port;

    @Value("${jeff.mail.username}")
    private String username;

    @Value("${jeff.mail.password}")
    private String password;



}
