package com.defitech.GestUni.service.Chahib;

import com.defitech.GestUni.dto.EtudiantDocDto;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.Utilisateur;
import com.defitech.GestUni.repository.EtudiantDocRepository;
import com.defitech.GestUni.repository.UtilisateurRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EtudiantDocServices {
    @Autowired
    private EtudiantDocRepository etudiantDR;

    @Autowired
    private UtilisateurRepository userR;

    public EtudiantDocDto getEtudiantByIdUser(Long idUser) {
        Utilisateur user = userR.findById(idUser)
                .orElseThrow(() -> new EntityNotFoundException("utilisateur non trouvé"));

        Etudiant etudiant = etudiantDR.findById(user.getEtudiant().getEtudiantId())
                .orElseThrow(() -> new EntityNotFoundException("etudiant introuvable pour cet : " + idUser));
        return new EtudiantDocDto(
                etudiant.getEtudiantId(),
                etudiant.getNom(),
                etudiant.getPrenom(),
                etudiant.getEmail(),
                etudiant.getMatricule()
        );
    }



}
