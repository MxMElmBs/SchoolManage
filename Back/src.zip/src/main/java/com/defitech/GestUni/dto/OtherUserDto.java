package com.defitech.GestUni.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OtherUserDto {
    private String nom;
    private String prenom;
    private String email;
}
