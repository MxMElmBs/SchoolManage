package com.defitech.GestUni.enums;

public enum StatutCahier {
    ENREGISTRER, CONFIRMER
}
