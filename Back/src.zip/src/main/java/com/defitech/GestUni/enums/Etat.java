package com.defitech.GestUni.enums;

public enum Etat {
    NORMALE, TERMINEE, EN_RETARD
}
