package com.defitech.GestUni.service.BEDJRA;

import com.defitech.GestUni.dto.BEDJRA.DtoFiliere;
import com.defitech.GestUni.dto.BEDJRA.EcheanceDto;
import com.defitech.GestUni.dto.BEDJRA.PaiementDto;
import com.defitech.GestUni.dto.BEDJRA.StudentDto;
import com.defitech.GestUni.enums.BEDJRA.StatutEcheance;
import com.defitech.GestUni.enums.BEDJRA.StatutScolarite;
import com.defitech.GestUni.enums.BEDJRA.TypeModalite;
import com.defitech.GestUni.enums.NiveauEtude;
import com.defitech.GestUni.models.BEDJRA.Echeance;
import com.defitech.GestUni.models.BEDJRA.Paiement;
import com.defitech.GestUni.models.BEDJRA.Reduction;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.Filiere;
import com.defitech.GestUni.models.Bases.Tuteur;
import com.defitech.GestUni.repository.BEDJRA.EcheanceRepository;
import com.defitech.GestUni.repository.BEDJRA.PaiementRepository;
import com.defitech.GestUni.repository.BEDJRA.ReductionRepository;
import com.defitech.GestUni.repository.BEDJRA.StudentRepository;
import com.defitech.GestUni.repository.EtudiantRepository;
import com.defitech.GestUni.repository.FiliereRepository;
import com.defitech.GestUni.repository.ParcoursRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class PaiementService {

    @Autowired
    private EmailService emailService;
    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ParcoursRepository parcoursRepository;

    @Autowired
    private ReductionRepository reductionRepository;


    @Autowired
    private EtudiantRepository etudiantRepository;
    @Autowired
    private EcheanceRepository echeanceRepository;
    @Autowired
    private PaiementRepository paiementRepository;
    @Autowired
    private FiliereRepository filiereRepository;


    //////////////////////////get NMBRE TOTAL ///////
    public long getTotalEtudiants() {
        return etudiantRepository.countTotalEtudiants();
    }
    // Compter le nombre d'étudiants dont le reste à payer est 0 (soldé)
    public long compterEtudiantsSoldes() {
        return paiementRepository.countEtudiantsSoldes();
    }
    // Méthode pour obtenir le nombre d'étudiants n'ayant pas encore soldé
    public long compterEtudiantsNonSoldes() {
        long totalEtudiants = getTotalEtudiants();
        long etudiantsSoldes = compterEtudiantsSoldes();
        return totalEtudiants - etudiantsSoldes;
    }



    public List<Etudiant> searchByNomOrPrenom(String searchTerm) {
        return etudiantRepository.findByNomStartingWithOrPrenomStartingWith(searchTerm, searchTerm);
    }


    public List<Etudiant> findByPaiementDto(PaiementDto paiementDto) {
        return etudiantRepository.findByNomAndPrenom(paiementDto.getEtudiantNom(), paiementDto.getEtudiantPrenom());
    }


    @Transactional
    public PaiementDto effectuerPaiement(PaiementDto paiementDto) {
        // Vérifier si montantActuel est négatif
        long montantActuel = paiementDto.getMontantActuel();
        if (montantActuel < 0) {
            throw new RuntimeException("Le montant actuel ne peut pas être négatif.");
        }

        // Récupérer l'étudiant
        List<Etudiant> etudiants = etudiantRepository.findByNomAndPrenom(paiementDto.getEtudiantNom(), paiementDto.getEtudiantPrenom());
        if (etudiants.isEmpty()) {
            throw new RuntimeException("Aucun étudiant trouvé avec les nom et prénom spécifiés.");
        }
        Etudiant etudiant = etudiants.get(0);

        // Calculer le montant déjà payé avant ce paiement
        List<Paiement> paiements = paiementRepository.findByEtudiant(etudiant);
        long montantDejaPaye = paiements.stream().mapToLong(Paiement::getMontantActuel).sum();

        // Ajouter le montant actuel payé
        montantDejaPaye += montantActuel;

        // Calculer le montant final et ajuster montantDejaPaye si nécessaire
        Reduction reduction = etudiant.getReduction();
        long montantFinal = (reduction != null) ? reduction.getMontantFinal() : 0;

        // S'assurer que montantDejaPaye ne dépasse pas montantFinal
        if (montantDejaPaye > montantFinal) {
            montantDejaPaye = montantFinal; // Ajustement pour éviter des montants négatifs
        }

        // Calculer le reste à payer
        long resteEcolage = montantFinal - montantDejaPaye;

        // S'assurer que resteEcolage ne devient pas négatif
        resteEcolage = Math.max(resteEcolage, 0); // Met à 0 si le reste est négatif

        // Vérifier si montantActuel dépasse resteEcolage
        if (montantActuel > montantFinal) {
            throw new RuntimeException("Le montant ne peut pas dépasser le reste à payer.");
        }

        // Mettre à jour le paiement
        Paiement paiement = new Paiement();
        paiement.setEtudiant(etudiant);
        paiement.setMontantActuel(montantActuel); // Utiliser le montant actuel payé
        paiement.setDatePaiement(paiementDto.getDatePaiement());
        paiement.setMontantDejaPaye(montantDejaPaye); // Mettre à jour le montant déjà payé
        paiement.setResteEcolage(resteEcolage); // Mettre à jour le reste à payer

        paiementRepository.save(paiement);

        // Déterminer le statut de scolarité
        if (resteEcolage == 0) {
            paiement.setStatutScolarite(StatutScolarite.SOLDE);
        } else {
            paiement.setStatutScolarite(StatutScolarite.EN_COURS);
        }

        // Préparer la réponse
        PaiementDto paiementRequest = new PaiementDto();
        paiementRequest.setEtudiantId(etudiant.getEtudiantId());
        paiementRequest.setEtudiantNom(etudiant.getNom());
        paiementRequest.setEtudiantPrenom(etudiant.getPrenom());
        paiementRequest.setEtudiantMatricule(etudiant.getMatricule());
        paiementRequest.setFiliereNom(etudiant.getFiliere().getNomFiliere());
        paiementRequest.setParcoursNom(etudiant.getParcours().getNomParcours());
        paiementRequest.setReductionMontantFinal(montantFinal);
        paiementRequest.setNiveauEtude(etudiant.getNiveauEtude());
        paiementRequest.setMontantDejaPaye(montantDejaPaye);
        paiementRequest.setDatePaiement(paiementDto.getDatePaiement());
        paiementRequest.setMontantActuel(montantActuel); // Utiliser le montant actuel payé
        paiementRequest.setResteEcolage(resteEcolage);
        paiementRequest.setStatutScolarite((resteEcolage == 0) ? StatutScolarite.SOLDE : StatutScolarite.EN_COURS);

        return paiementRequest;
    }



    public List<PaiementDto> getAllPaiements() {
        List<Paiement> paiements = paiementRepository.findAll();

        return paiements.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    private PaiementDto convertToDto(Paiement paiement) {
        PaiementDto paiementDto = new PaiementDto();
        paiementDto.setEtudiantId(paiement.getEtudiant().getEtudiantId());
        paiementDto.setEtudiantNom(paiement.getEtudiant().getNom());
        paiementDto.setEtudiantPrenom(paiement.getEtudiant().getPrenom());
        paiementDto.setEtudiantMatricule(paiement.getEtudiant().getMatricule());
        paiementDto.setMontantActuel(paiement.getMontantActuel());
        paiementDto.setDatePaiement(paiement.getDatePaiement());
        paiementDto.setMontantDejaPaye(paiement.getMontantDejaPaye());
        paiementDto.setResteEcolage(paiement.getResteEcolage());
        // Ajoutez d'autres champs que vous souhaitez inclure dans le DTO
        return paiementDto;
    }

    /////////////put//////////////////////////////////////
//    @Transactional
//    public PaiementDto updatePaiement(String nomEtudiant, String prenomEtudiant, PaiementDto paiementDto) {
//        // Vérification des paramètres
//        if (paiementDto == null) {
//            throw new IllegalArgumentException("Le paiementDto ne peut pas être nul.");
//        }
//
//        // Étape 1 : Récupérer l'étudiant par nom et prénom
//        List<Etudiant> etudiants = etudiantRepository.findByNomAndPrenom(nomEtudiant, prenomEtudiant);
//        if (etudiants.isEmpty()) {
//            throw new RuntimeException("Aucun étudiant trouvé avec le nom et prénom spécifiés.");
//        }
//        Etudiant etudiant = etudiants.get(0); // Prendre le premier étudiant trouvé
//
//        // Étape 2 : Récupérer le dernier paiement
//        Paiement dernierPaiement = paiementRepository.findTopByEtudiantOrderByDatePaiementDesc(etudiant);
//        if (dernierPaiement == null) {
//            throw new RuntimeException("Aucun paiement trouvé pour cet étudiant.");
//        }
//
//        // Étape 3 : Mettre à jour le dernier paiement
//        dernierPaiement.setMontantActuel(paiementDto.getMontantActuel());
//        dernierPaiement.setDatePaiement(paiementDto.getDatePaiement());
//        paiementRepository.save(dernierPaiement);
//
//        // Étape 4 : Recalculer le montant déjà payé
//        long montantDejaPaye = paiementRepository.sumMontantByEtudiant(etudiant); // Requête d'agrégation
//
//        // Étape 5 : Calculer le reste à payer
//        Reduction reduction = etudiant.getReduction();
//        long montantFinal = (reduction != null) ? reduction.getMontantFinal() : 0;
//        long resteEcolage = montantFinal - montantDejaPaye;
//
//        // Étape 6 : Préparer la réponse
//        PaiementDto paiementRequest = new PaiementDto();
//        paiementRequest.setEtudiantId(etudiant.getEtudiantId());
//        paiementRequest.setMontantDejaPaye(montantDejaPaye);
//        paiementRequest.setResteEcolage(resteEcolage);
//        paiementRequest.setEcheances(calculerEcheances(etudiant, montantFinal, montantDejaPaye));
//
//        return paiementRequest;
//    }


    @Transactional
//    public PaiementDto updatePaiement(Long paiementId, long nouveauMontant) {
//        // Récupérer le paiement existant à partir de l'ID
//        Paiement paiementExistant = paiementRepository.findById(paiementId)
//                .orElseThrow(() -> new RuntimeException("Paiement introuvable avec l'ID spécifié."));
//
//        // Récupérer l'étudiant associé
//        Etudiant etudiant = paiementExistant.getEtudiant();
//        if (etudiant == null) {
//            throw new RuntimeException("Aucun étudiant associé à ce paiement.");
//        }
//
//        // Récupérer tous les paiements de cet étudiant pour calculer le montant déjà payé
//        List<Paiement> paiements = paiementRepository.findByEtudiant(etudiant);
//        long montantDejaPaye = paiements.stream()
//                .filter(p -> !p.getId().equals(paiementId)) // Exclure le paiement actuel de la somme
//                .mapToLong(Paiement::getMontantActuel)
//                .sum();
//
//        // Calculer le montant final de scolarité
//        Reduction reduction = etudiant.getReduction();
//        long montantFinal = (reduction != null) ? reduction.getMontantFinal() : 0;
//
//        // Mettre à jour le montant déjà payé avec le nouveau montant fourni
//        montantDejaPaye += nouveauMontant;
//
//        // S'assurer que le montant déjà payé ne dépasse pas le montant final
//        if (montantDejaPaye > montantFinal) {
//            throw new RuntimeException("Le montant total payé ne peut pas dépasser le montant final des frais de scolarité.");
//        }
//
//        // Calculer le nouveau reste à payer
//        long resteEcolage = montantFinal - montantDejaPaye;
//
//        // S'assurer que resteEcolage ne devient pas négatif
//        resteEcolage = Math.max(resteEcolage, 0);
//
//        // Mettre à jour le paiement existant avec le nouveau montant et le reste à payer
//        paiementExistant.setMontantActuel(nouveauMontant);
//        paiementExistant.setMontantDejaPaye(montantDejaPaye);
//        paiementExistant.setResteEcolage(resteEcolage);
//
//        // Déterminer le statut de scolarité après la mise à jour
//        if (resteEcolage == 0) {
//            paiementExistant.setStatutScolarite(StatutScolarite.SOLDE);
//        } else {
//            paiementExistant.setStatutScolarite(StatutScolarite.EN_COURS);
//        }
//
//        // Sauvegarder le paiement mis à jour
//        paiementRepository.save(paiementExistant);
//
//        // Mettre à jour les échéances en fonction du nouveau montant payé
//        TypeModalite modalite = etudiant.getTypeModalite();
//        Integer nombreEcheances = obtenirNombreEcheancesPourModalite(modalite);
//
//        // Date de début ajustée au 14 novembre de l'année en cours
//        LocalDate dateFinEcheance = LocalDate.now().withMonth(11).withDayOfMonth(14);
//
//        // Créer ou mettre à jour les échéances existantes
//        List<EcheanceDto> echeanceDTOs = new ArrayList<>();
//        if (nombreEcheances == 1) {
//            // Cas où la modalité est 'TOTALITE', donc une seule échéance
//            EcheanceDto echeanceDto = new EcheanceDto();
//            echeanceDto.setId(1L);
//            echeanceDto.setMontantParEcheance(montantFinal); // Le montant total est dû en une seule échéance
//            echeanceDto.setDateEcheance(dateFinEcheance);
//
//            // Vérifier le statut de cette unique échéance
//            if (montantDejaPaye >= montantFinal) {
//                echeanceDto.setStatut(StatutEcheance.PAYEE);
//            } else if (montantDejaPaye > 0) {
//                echeanceDto.setStatut(StatutEcheance.PARTIELLEMENT_PAYEE);
//            } else {
//                echeanceDto.setStatut(StatutEcheance.EN_ATTENTE);
//            }
//
//            echeanceDTOs.add(echeanceDto);
//        } else {
//            // Cas pour les modalités 'TROIS_TRANCHES' et 'SEPT_TRANCHES'
//            long montantSuppl = 10000; // Montant supplémentaire pour la première échéance
//            long montantParEcheance = (montantFinal - montantSuppl) / (nombreEcheances - 1);
//
//            for (int i = 0; i < nombreEcheances; i++) {
//                EcheanceDto echeanceDto = new EcheanceDto();
//                echeanceDto.setId(Long.valueOf(i + 1));
//
//                long montantPourCetteEcheance;
//                if (i == 0) {
//                    montantPourCetteEcheance = montantParEcheance + montantSuppl;
//                } else {
//                    montantPourCetteEcheance = montantParEcheance;
//                }
//
//                echeanceDto.setMontantParEcheance(montantPourCetteEcheance);
//                echeanceDto.setDateEcheance(calculerProchaineDateEcheance(i, modalite, dateFinEcheance));
//
//                // Vérification de l'état de chaque échéance
//                if (montantDejaPaye >= montantPourCetteEcheance) {
//                    echeanceDto.setStatut(StatutEcheance.PAYEE);
//                    montantDejaPaye -= montantPourCetteEcheance;
//                } else if (montantDejaPaye > 0 && montantDejaPaye < montantPourCetteEcheance) {
//                    echeanceDto.setStatut(StatutEcheance.PARTIELLEMENT_PAYEE);
//                    montantDejaPaye = 0;
//                } else {
//                    echeanceDto.setStatut(StatutEcheance.EN_ATTENTE);
//                }
//
//                echeanceDTOs.add(echeanceDto);
//            }
//        }
//
//        // Préparer la réponse DTO avec les informations mises à jour
//        PaiementDto paiementDto = new PaiementDto();
//        paiementDto.setEtudiantId(etudiant.getEtudiantId());
//        paiementDto.setEtudiantNom(etudiant.getNom());
//        paiementDto.setEtudiantPrenom(etudiant.getPrenom());
//        paiementDto.setEtudiantMatricule(etudiant.getMatricule());
//        paiementDto.setFiliereNom(etudiant.getFiliere().getNomFiliere());
//        paiementDto.setParcoursNom(etudiant.getParcours().getNomParcours());
//        paiementDto.setReductionMontantFinal(montantFinal);
//        paiementDto.setNiveauEtude(etudiant.getNiveauEtude());
//        paiementDto.setMontantDejaPaye(montantDejaPaye);
//        paiementDto.setTypeModalite(TypeModalite.valueOf(modalite.name()));
//        paiementDto.setMontantActuel(nouveauMontant);
//        paiementDto.setDatePaiement(paiementExistant.getDatePaiement());
//        paiementDto.setResteEcolage(resteEcolage);
//        paiementDto.setEcheances(echeanceDTOs);
//        paiementDto.setStatutScolarite(paiementExistant.getStatutScolarite());
//
//        return paiementDto;
//    }

//    private List<EcheanceDto> calculerEcheances(Etudiant etudiant, long montantFinal, long montantDejaPaye) {
//        List<EcheanceDto> echeanceDTOs = new ArrayList<>();
//
//        // Étape 1 : Récupérer la modalité de l'étudiant
//        TypeModalite modalite = etudiant.getTypeModalite();
//
//        // Étape 2 : Déterminer le nombre d'échéances
//        Integer nombreEcheances = obtenirNombreEcheancesPourModalite(modalite);
//
//        // Étape 3 : Calculer le montant par échéance
//        long montantParEcheance = montantFinal / nombreEcheances;
//        long montantRestant = montantFinal % nombreEcheances; // Pour ajuster le premier paiement
//
//        // Date de début pour les échéances
//        LocalDate dateFinEcheance = LocalDate.now().withMonth(11).withDayOfMonth(14); // Date de début pour les échéances
//
//        // Étape 4 : Créer les échéances
//        for (int i = 0; i < nombreEcheances; i++) {
//            EcheanceDto echeanceDto = new EcheanceDto();
//            echeanceDto.setId(Long.valueOf(i + 1));
//
//            // Ajuster le montant pour la première échéance
//            long montantPourCetteEcheance = (i == 0) ? montantParEcheance + montantRestant : montantParEcheance;
//
//            echeanceDto.setMontantParEcheance(montantPourCetteEcheance);
//            echeanceDto.setDateEcheance(calculerProchaineDateEcheance(i, modalite, dateFinEcheance));
//
//            // Vérification de l'état de chaque échéance
//            if (montantDejaPaye >= montantPourCetteEcheance) {
//                // Cas où l'échéance est totalement payée
//                echeanceDto.setStatut(StatutEcheance.PAYEE);
//                montantDejaPaye -= montantPourCetteEcheance;
//            } else if (montantDejaPaye > 0) {
//                // Cas où l'échéance est partiellement payée
//                echeanceDto.setStatut(StatutEcheance.PARTIELLEMENT_PAYEE);
//                montantDejaPaye = 0; // Le reste du montant est maintenant épuisé
//            } else {
//                // Cas où l'échéance est en attente de paiement
//                echeanceDto.setStatut(StatutEcheance.EN_ATTENTE);
//            }
//
//            echeanceDTOs.add(echeanceDto);
//        }
//
//        return echeanceDTOs;
//    }


    public List<DtoFiliere> getAllFiliereDtos() {
        // Récupérer toutes les filières depuis la base de données
        List<Filiere> filieres = filiereRepository.findAll();

        // Mapper les objets Filiere vers des DtoFiliere
        return filieres.stream().map(this::mapToDtoFiliere).collect(Collectors.toList());
    }

    // Méthode de mapping de Filiere vers DtoFiliere
    private DtoFiliere mapToDtoFiliere(Filiere filiere) {
        DtoFiliere dtoFiliere = new DtoFiliere();
        dtoFiliere.setNomFiliere(filiere.getNomFiliere()); // Mapper uniquement le nom de la filière
        return dtoFiliere;
    }


    public List<PaiementDto> getDernierPaiementByFiliereAndNiveau(String nomFiliere, String niveauEtude) {
        // Rechercher la filière par nom
        Filiere filiere = filiereRepository.findByNomFiliere(nomFiliere).orElseThrow(() -> new RuntimeException("Filière non trouvée"));

        // Valider le niveau d'étude
        NiveauEtude niveau;
        try {
            niveau = NiveauEtude.valueOf(niveauEtude.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Niveau d'étude invalide");
        }

        // Récupérer les étudiants par filière et niveau d'étude
        List<Etudiant> etudiants = etudiantRepository.findByFiliereAndNiveauEtude(filiere, niveau);

        // Récupérer tous les paiements pour les étudiants
        List<Paiement> paiements = paiementRepository.findByEtudiantIn(etudiants);

        // Map pour stocker le dernier paiement de chaque étudiant
        Map<Etudiant, Paiement> dernierPaiementMap = new HashMap<>();

        for (Paiement paiement : paiements) {
            Etudiant etudiant = paiement.getEtudiant();
            // Si l'étudiant n'est pas encore dans la map ou si le paiement est plus récent
            dernierPaiementMap.merge(etudiant, paiement, (ancien, nouveau) -> ancien.getDatePaiement().isAfter(nouveau.getDatePaiement()) ? ancien : nouveau);
        }

        // Convertir la map en liste de DTO
        List<PaiementDto> paiementDtos = new ArrayList<>();
        for (Map.Entry<Etudiant, Paiement> entry : dernierPaiementMap.entrySet()) {
            Etudiant etudiant = entry.getKey();
            Paiement dernierPaiement = entry.getValue();

            PaiementDto dto = new PaiementDto();
            dto.setEtudiantId(etudiant.getEtudiantId());
            dto.setEtudiantNom(etudiant.getNom());
            dto.setEtudiantPrenom(etudiant.getPrenom());
            dto.setEtudiantMatricule(etudiant.getMatricule());
            dto.setFiliereNom(etudiant.getFiliere().getNomFiliere());
            dto.setParcoursNom(etudiant.getParcours().getNomParcours());
            dto.setReductionMontantFinal(etudiant.getReduction().getMontantFinal());
            dto.setNiveauEtude(etudiant.getNiveauEtude());
            dto.setMontantDejaPaye(dernierPaiement.getMontantDejaPaye());
            dto.setTypeModalite(etudiant.getTypeModalite());
            dto.setDatePaiement(dernierPaiement.getDatePaiement());
            dto.setMontantActuel(dernierPaiement.getMontantActuel());
            dto.setResteEcolage(dernierPaiement.getResteEcolage());

//            // Ajouter le calcul des échéances basé sur la modalité
//            List<EcheanceDto> echeances = calculerEcheancesPourPaiement(etudiant, dernierPaiement);
//            dto.setEcheances(echeances);

            paiementDtos.add(dto);
        }

        // Trier les DTOs par ID d'étudiant en ordre croissant
        return paiementDtos.stream().sorted(Comparator.comparing(PaiementDto::getEtudiantId)).collect(Collectors.toList());
    }


//    private List<EcheanceDto> calculerEcheancesPourPaiement(Etudiant etudiant, Paiement paiement) {
//        TypeModalite modalite = etudiant.getTypeModalite();
////        Integer nombreEcheances = obtenirNombreEcheancesPourModalite(modalite);
//
//        // Date de début ajustée au 14 octobre de l'année en cours
//        LocalDate dateDebut = LocalDate.now().withMonth(11).withDayOfMonth(14);
//
//        long montantFinal = etudiant.getReduction().getMontantFinal();
//        long montantDejaPaye = paiement.getMontantDejaPaye();
//
//        // Diviser le montant final par le nombre d'échéances, en arrondissant à l'entier inférieur
//        long montantParEcheance = montantFinal / nombreEcheances;
//
//        // Calculer le montant restant à répartir
//        long montantRestant = montantFinal % nombreEcheances;
//
//        List<EcheanceDto> echeanceDTOs = new ArrayList<>();
//
//        for (int i = 0; i < nombreEcheances; i++) {
//            EcheanceDto echeanceDto = new EcheanceDto();
//            echeanceDto.setId(Long.valueOf(i + 1));
//
//            // Ajuster la première ou les premières échéances pour inclure le montant restant
//            long montantPourCetteEcheance = (i == 0) ? montantParEcheance + montantRestant : montantParEcheance;
//
//            echeanceDto.setMontantParEcheance(montantPourCetteEcheance);
//            echeanceDto.setDateEcheance(calculerProchaineDateEcheance(i, modalite, dateDebut));
//
//            // Vérification de l'état de chaque échéance
//            if (montantDejaPaye >= montantPourCetteEcheance) {
//                echeanceDto.setStatut(StatutEcheance.PAYEE);
//                montantDejaPaye -= montantPourCetteEcheance;
//            } else if (montantDejaPaye > 0 && montantDejaPaye < montantPourCetteEcheance) {
//                echeanceDto.setStatut(StatutEcheance.PARTIELLEMENT_PAYEE);
//                montantDejaPaye = 0;
//            } else {
//                echeanceDto.setStatut(StatutEcheance.EN_ATTENTE);
//            }
//
//            echeanceDTOs.add(echeanceDto);
//        }
//
//        return echeanceDTOs;
//    }


    public List<PaiementDto> getPaiementsEnCours() {
        List<Paiement> paiementsEnCours = paiementRepository.findByStatutScolarite(StatutScolarite.EN_COURS);
        List<PaiementDto> paiementDtos = new ArrayList<>();
        for (Paiement paiement : paiementsEnCours) {
            // Vérifier s'il existe un paiement pour cet étudiant avec le statut SOLDE
            boolean hasSolde = paiementRepository.existsByEtudiantAndStatutScolarite(paiement.getEtudiant(), StatutScolarite.SOLDE);

            // Ignorer cet étudiant s'il a un statut SOLDE
            if (hasSolde) {
                continue;
            }

            // Créer le DTO et ajouter à la liste seulement si resteEcolage > 0
            PaiementDto paiementDto = new PaiementDto();
            paiementDto.setEtudiantNom(paiement.getEtudiant().getNom());
            paiementDto.setEtudiantPrenom(paiement.getEtudiant().getPrenom());
            paiementDto.setFiliereNom(paiement.getEtudiant().getFiliere().getNomFiliere());
            paiementDto.setParcoursNom(paiement.getEtudiant().getParcours().getNomParcours());
            paiementDto.setReductionMontantFinal(paiement.getEtudiant().getReduction().getMontantFinal());
            paiementDto.setNiveauEtude(paiement.getEtudiant().getNiveauEtude());
            paiementDto.setMontantDejaPaye(paiement.getMontantDejaPaye());
            paiementDto.setResteEcolage(paiement.getResteEcolage());

            // Ajouter à la liste seulement si resteEcolage > 0
            if (paiementDto.getResteEcolage() > 0) {
                paiementDtos.add(paiementDto);
            }
        }
        return paiementDtos;
    }


    public List<Paiement> getPaiementsAvecEcheancesNonPayees() {
        List<Paiement> paiementsEnCours = paiementRepository.findByStatutScolarite(StatutScolarite.EN_COURS);
        List<Paiement> paiementsAvecEcheancesNonPayees = new ArrayList<>();

        for (Paiement paiement : paiementsEnCours) {
            Etudiant etudiant = paiement.getEtudiant();

            // Vérifiez les échéances non payées et partiellement payées
            List<Echeance> echeancesNonPayees = echeanceRepository.findByEtudiantAndStatutNot(etudiant, StatutEcheance.EN_ATTENTE);
            List<Echeance> echeancesPartiellementPayees = echeanceRepository.findByEtudiantAndStatut(etudiant, StatutEcheance.PARTIELLEMENT_PAYEE);

            // Ajoutez le paiement si des échéances non payées ou partiellement payées existent
            if (!echeancesNonPayees.isEmpty() || !echeancesPartiellementPayees.isEmpty()) {
                paiementsAvecEcheancesNonPayees.add(paiement);
            }
        }

        return paiementsAvecEcheancesNonPayees;
    }



///////////////////////////////////////////////////////////////////
    /////////////////////RAPPELS////////////////////////
public List<Paiement> getPaiementsEncoreEnCours() {
    // Récupère la date actuelle
    LocalDate currentDate = LocalDate.now();

    // Requête pour trouver le dernier paiement de chaque étudiant dont le montant déjà payé est inférieur à l'échéance actuelle
    List<Paiement> paiementsEnCours = paiementRepository.findPaiementsEncoreEnCours(currentDate);

    return paiementsEnCours;
}




}


