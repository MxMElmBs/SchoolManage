package com.defitech.GestUni.enums;

public enum PermissionType {
    ANTICIPATED, LATE
}
