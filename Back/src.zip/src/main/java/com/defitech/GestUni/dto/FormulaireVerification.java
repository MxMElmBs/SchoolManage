package com.defitech.GestUni.dto;

import lombok.Data;

@Data
public class FormulaireVerification {
    private String introduction;
    private String resume_dia_classe;
    private String resume_dia_sequence;
    private String resumeDoc;
    private String conclusion;
}
