package com.defitech.GestUni.config;

public interface SecurityConfiguration {
}
