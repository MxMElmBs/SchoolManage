package com.defitech.GestUni.repository.BEDJRA;

public interface ModaliteRepository {
}
