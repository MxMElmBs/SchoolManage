package com.defitech.GestUni.dto.BEDJRA;

public class DtoFiliere {
    private String nomFiliere;

    public String getNomFiliere() {
        return nomFiliere;
    }

    public void setNomFiliere(String nomFiliere) {
        this.nomFiliere = nomFiliere;
    }
}
