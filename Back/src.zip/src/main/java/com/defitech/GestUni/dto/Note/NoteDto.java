package com.defitech.GestUni.dto.Note;

import com.defitech.GestUni.enums.TypeNote;
import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.UE;
import lombok.Data;

@Data
public class NoteDto {
    private Etudiant etudiant;
    private Long ueId;
    private float valeur;
    private TypeNote tYpeNote;
    private TypeSemestre semestre;

}
