package com.defitech.GestUni.models.BAKA.JeffService;

import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;


@Service
public class BulletinPdfService {

    @Autowired
    private EtudiantjeffService etudiantjeffService;
    @Autowired
    private JeffEmailService emailService;

    public void genererBulletinPDF(Long etudiantId, HttpServletResponse response) throws IOException {
        // Récupérer les données de l'étudiant
        Etudiant etudiant = etudiantjeffService.getEtudiantById(etudiantId);
        Map<String, Object> bulletinData = etudiantjeffService.getUeDetailsParSemestre(etudiantId);

        String nomFichier = "Bulletin_" + etudiant.getNom() + "_" + etudiant.getMatricule() + ".pdf";
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=" + nomFichier);

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Titre principal
        document.add(new Paragraph("Bulletin de Notes")
                .setBold().setFontSize(18).setTextAlignment(TextAlignment.CENTER));

        // Informations de l'étudiant
        document.add(new Paragraph("Nom : " + etudiant.getNom()));
        document.add(new Paragraph("Prénom : " + etudiant.getPrenom()));
        document.add(new Paragraph("Matricule : " + etudiant.getMatricule()));
        document.add(new Paragraph("Date de naissance : " + etudiant.getDateNaiss()));
        document.add(new Paragraph("Niveau d'étude : " + etudiant.getNiveauEtude().name()));
        document.add(new Paragraph("\n"));  // Saut de ligne


        // Récupérer les détails par semestre
        Map<TypeSemestre, Map<String, Object>> ueDetailsBySemestre = (Map<TypeSemestre, Map<String, Object>>) bulletinData.get("ueDetailsBySemestre");

        for (Map.Entry<TypeSemestre, Map<String, Object>> entry : ueDetailsBySemestre.entrySet()) {
            TypeSemestre semestre = entry.getKey();
            Map<String, Object> semestreDetails = entry.getValue();
            List<Map<String, Object>> ueDetailsList = (List<Map<String, Object>>) semestreDetails.get("ueDetails");

            // Titre du semestre
            document.add(new Paragraph("Semestre : " + semestre.name())
                    .setBold().setFontSize(14).setTextAlignment(TextAlignment.LEFT));

            // Tableau des UE
            Table table = new Table(new float[]{1, 3, 2, 1, 1, 1, 2});
            table.setWidth(UnitValue.createPercentValue(100));
            table.addHeaderCell(new Cell().add(new Paragraph("Code UE")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Unité d'Enseignement")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Type")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Crédit")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Note")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Validé")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
            table.addHeaderCell(new Cell().add(new Paragraph("Appréciation")).setBackgroundColor(ColorConstants.LIGHT_GRAY));

            // Ajouter les UE au tableau
            for (Map<String, Object> ueDetails : ueDetailsList) {
                table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("codeUE"))));
                table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("libelle"))));
                table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("type"))));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("credit")))));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("note")))));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("valide")))));
                table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("appreciation"))));
            }
            document.add(table);

            // Afficher les moyennes et crédits
            document.add(new Paragraph("Moyenne Semestre : " + semestreDetails.get("moyenneSemestre")));
            document.add(new Paragraph("Crédits Validés : " + semestreDetails.get("creditsValides")));
            document.add(new Paragraph("Total Crédits : " + semestreDetails.get("totalCredits")));
            document.add(new Paragraph("\n"));  // Saut de ligne
        }

        // Moyenne du niveau
        document.add(new Paragraph("Moyenne du Niveau : " + bulletinData.get("moyenneNiveau")).setBold());
        document.add(new Paragraph("Mention : " + bulletinData.get("mention")).setBold());

        document.close();
    }

    public void genererEtEnvoyerBulletinPDF(Long etudiantId) throws IOException, MessagingException {
        // Récupérer les données de l'étudiant
        Etudiant etudiant = etudiantjeffService.getEtudiantById(etudiantId);
        Map<String, Object> bulletinData = etudiantjeffService.getUeDetailsParSemestre(etudiantId);

        // Créer le nom du fichier PDF
        String nomFichier = etudiant.getNom() + "_" + etudiant.getMatricule() + ".pdf";

        // Générer le PDF
        Path tempFile = Files.createTempFile(nomFichier, ".pdf");
        try (OutputStream outputStream = Files.newOutputStream(tempFile);
             PdfWriter writer = new PdfWriter(outputStream);
             PdfDocument pdf = new PdfDocument(writer);
             Document document = new Document(pdf)) {

            // Ajoutez le contenu du PDF comme dans votre méthode existante
            document.add(new Paragraph("Bulletin de Notes")
                    .setBold().setFontSize(18).setTextAlignment(TextAlignment.CENTER));

            document.add(new Paragraph("Nom : " + etudiant.getNom()));
            document.add(new Paragraph("Prénom : " + etudiant.getPrenom()));
            document.add(new Paragraph("Matricule : " + etudiant.getMatricule()));
            document.add(new Paragraph("Date de naissance : " + etudiant.getDateNaiss()));
            document.add(new Paragraph("Niveau d'étude : " + etudiant.getNiveauEtude().name()));
            document.add(new Paragraph("\n"));

            Map<TypeSemestre, Map<String, Object>> ueDetailsBySemestre = (Map<TypeSemestre, Map<String, Object>>) bulletinData.get("ueDetailsBySemestre");

            for (Map.Entry<TypeSemestre, Map<String, Object>> entry : ueDetailsBySemestre.entrySet()) {
                TypeSemestre semestre = entry.getKey();
                Map<String, Object> semestreDetails = entry.getValue();
                List<Map<String, Object>> ueDetailsList = (List<Map<String, Object>>) semestreDetails.get("ueDetails");

                document.add(new Paragraph("Semestre : " + semestre.name())
                        .setBold().setFontSize(14).setTextAlignment(TextAlignment.LEFT));

                Table table = new Table(new float[]{1, 3, 2, 1, 1, 1, 2});
                table.setWidth(UnitValue.createPercentValue(100));
                table.addHeaderCell(new Cell().add(new Paragraph("Code UE")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Unité d'Enseignement")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Type")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Crédit")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Note")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Validé")).setBackgroundColor(ColorConstants.LIGHT_GRAY));
                table.addHeaderCell(new Cell().add(new Paragraph("Appréciation")).setBackgroundColor(ColorConstants.LIGHT_GRAY));

                for (Map<String, Object> ueDetails : ueDetailsList) {
                    table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("codeUE"))));
                    table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("libelle"))));
                    table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("type"))));
                    table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("credit")))));
                    table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("note")))));
                    table.addCell(new Cell().add(new Paragraph(String.valueOf(ueDetails.get("valide")))));
                    table.addCell(new Cell().add(new Paragraph((String) ueDetails.get("appreciation"))));
                }
                document.add(table);

                document.add(new Paragraph("Moyenne Semestre : " + semestreDetails.get("moyenneSemestre")));
                document.add(new Paragraph("Crédits Validés : " + semestreDetails.get("creditsValides")));
                document.add(new Paragraph("Total Crédits : " + semestreDetails.get("totalCredits")));
                document.add(new Paragraph("\n"));
            }

            document.add(new Paragraph("Moyenne du Niveau : " + bulletinData.get("moyenneNiveau")).setBold());
            document.add(new Paragraph("Mention : " + bulletinData.get("mention")).setBold());
        }

        String mailetudiant = etudiant.getEmail();
        // Envoyer l'email avec le PDF en pièce jointe
        emailService.sendEmail(mailetudiant, "Votre bulletin", "Veuillez trouver en pièce jointe votre bulletin.", tempFile.toString());

        // Supprimer le fichier temporaire après l'envoi
        Files.deleteIfExists(tempFile);
    }
}
