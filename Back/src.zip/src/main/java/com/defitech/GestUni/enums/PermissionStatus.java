package com.defitech.GestUni.enums;

public enum PermissionStatus {
    EN_ATTENTE, ACCEPTER, REJETER, EN_COURS, TERMINEE
}
