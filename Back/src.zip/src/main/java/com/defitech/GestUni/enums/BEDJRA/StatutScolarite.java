package com.defitech.GestUni.enums.BEDJRA;

public enum StatutScolarite {
    SOLDE,
    EN_COURS
}
