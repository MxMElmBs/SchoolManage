package com.defitech.GestUni.models.BAKA.JeffService;

import com.defitech.GestUni.dto.Note.EtudiantjeffDto;
import com.defitech.GestUni.enums.NiveauEtude;
import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.BAKA.JeffRepository.EtudiantjeffRepository;
import com.defitech.GestUni.models.BAKA.Note;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.UE;
import com.defitech.GestUni.repository.NoteRepository;
import com.defitech.GestUni.service.NoteService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class EtudiantjeffService {
//    @Autowired
//    private EtudiantjeffRepository etudiantRepository;
    @Autowired
    private EtudiantjeffRepository etudiantjeffRepository;
    @Autowired
    private NoteRepository noteRepository;
    @Autowired
    private NoteService notesService;

    public List<EtudiantjeffDto> getEtudiantsBySemestre(TypeSemestre typeSemestre) {
        List<Etudiant> etudiants = etudiantjeffRepository.findEtudiantsByTypeSemestre(typeSemestre);
        // Conversion en DTO si nécessaire
        return etudiants.stream().map(this::convertToEtudiantDto).collect(Collectors.toList());
    }
    public EtudiantjeffDto convertToEtudiantDto(Etudiant etudiant) {
        EtudiantjeffDto dto = new EtudiantjeffDto();
        dto.setId(etudiant.getEtudiantId());
        dto.setMatricule(etudiant.getMatricule());
        dto.setNom(etudiant.getNom());
        dto.setPrenom(etudiant.getPrenom());
        dto.setFiliere(etudiant.getFiliere().getNomFiliere()); // Exemple si la filière a un nom
        return dto;
    }

    public List<EtudiantjeffDto> getEtudiantsWithNotes() {
        List<Etudiant> etudiants = etudiantjeffRepository.findEtudiantsWithNotes();
        return etudiants.stream()
                .map(this::convertToEtudiantjeffDto) // Conversion de chaque Etudiant en EtudiantjeffDto
                .collect(Collectors.toList());
    }

    public EtudiantjeffDto convertToEtudiantjeffDto(Etudiant etudiant) {
        EtudiantjeffDto dto = new EtudiantjeffDto();
        dto.setId(etudiant.getEtudiantId());
        dto.setNom(etudiant.getNom());
        dto.setPrenom(etudiant.getPrenom());
        return dto;
    }

    public List<Etudiant> getEtudiantsByNiveau(NiveauEtude niveauEtude) {
        return etudiantjeffRepository.findByNiveauEtude(niveauEtude);
    }

    public Etudiant getEtudiantById(Long id) {
        return etudiantjeffRepository.findById(id).orElse(null);
    }

    //Les notes en fonction du niveau d'étude
    public List<Note> getNotesParNiveauEtude(Long etudiantId) {
        // Récupérer l'étudiant à partir de son ID
        Etudiant etudiant = etudiantjeffRepository.findById(etudiantId)
                .orElseThrow(() -> new RuntimeException("Étudiant introuvable"));

        // Déterminer les semestres associés au niveau d'étude
        List<TypeSemestre> semestresAssocies = getSemestresAssocies(etudiant.getNiveauEtude());

        // Récupérer les notes pour les semestres associés
        return getNotesBySemestres(etudiant, semestresAssocies);
    }

    // Méthode pour récupérer les semestres associés à un niveau d'étude
    private List<TypeSemestre> getSemestresAssocies(NiveauEtude niveauEtude) {
        switch (niveauEtude) {
            case PREMIERE_ANNEE:
                return Arrays.asList(TypeSemestre.SEMESTRE_1, TypeSemestre.SEMESTRE_2);
            case DEUXIEME_ANNEE:
                return Arrays.asList(TypeSemestre.SEMESTRE_3, TypeSemestre.SEMESTRE_4);
            case TROISIEME_ANNEE:
                return Arrays.asList(TypeSemestre.SEMESTRE_5, TypeSemestre.SEMESTRE_6);
            default:
                throw new RuntimeException("Niveau d'étude non reconnu");
        }
    }

    // Filtrer les notes d'un étudiant en fonction de semestres spécifiques
    public List<Note> getNotesBySemestres(Etudiant etudiant, List<TypeSemestre> semestres) {
        return etudiant.getNotes().stream()
                .filter(note -> note.getUe() != null && semestres.contains(note.getUe().getTypeSemestre()))  // Vérifier que l'UE n'est pas null
                .collect(Collectors.toList());
    }

    // Regrouper les notes par semestre
    public Map<TypeSemestre, List<Note>> getNotesBySemestres(Etudiant etudiant) {
        return etudiant.getNotes().stream()
                .filter(note -> note.getUe() != null)  // Vérification que l'UE n'est pas null
                .collect(Collectors.groupingBy(note -> note.getUe().getTypeSemestre()));
    }


    public Map<String, Object> getUeDetailsParSemestre(Long etudiantId) {
        // Logique existante pour récupérer les données des UE par semestre
        Etudiant etudiant = getEtudiantById(etudiantId);

        // Récupérer les notes par semestre pour cet étudiant
        Map<TypeSemestre, List<Note>> notesBySemestre = getNotesBySemestres(etudiant);
        Map<TypeSemestre, Map<String, Object>> ueDetailsBySemestre = new HashMap<>();

        double moyenneNiveau = 0.0;
        int totalSemestres = 0;

        for (Map.Entry<TypeSemestre, List<Note>> entry : notesBySemestre.entrySet()) {
            TypeSemestre semestre = entry.getKey();
            List<Note> notesSemestre = entry.getValue();

            // Grouper les notes par UE
            Map<UE, List<Note>> notesByUE = notesSemestre.stream().collect(Collectors.groupingBy(Note::getUe));
            List<Map<String, Object>> ueDetailsList = new ArrayList<>();

            int totalCreditsSemestre = 0;
            int creditsValides = 0;
            double moyenneSemestre = 0.0;

            for (Map.Entry<UE, List<Note>> ueEntry : notesByUE.entrySet()) {
                UE ue = ueEntry.getKey();
                List<Note> notesUE = ueEntry.getValue();

                // Calculer la moyenne de l'UE
                double moyenneUE = notesService.calculerMoyenneUE(notesUE);

                // Déterminer si l'UE est validée ou non (moyenne supérieure à 10)
                String valide = (moyenneUE >= 10) ? "OUI" : "NON";

                // Calculer l'appréciation
                String appreciation = notesService.AvoirAppreciation(moyenneUE);

                // Mettre à jour le total des crédits
                totalCreditsSemestre += ue.getCredit();
                if (moyenneUE >= 10) {
                    creditsValides += ue.getCredit();
                }

                // Construire les détails de l'UE
                Map<String, Object> ueDetails = new HashMap<>();
                ueDetails.put("codeUE", ue.getCode());
                ueDetails.put("libelle", ue.getLibelle());
                ueDetails.put("type", ue.getTypeUe());
                ueDetails.put("credit", ue.getCredit());
                ueDetails.put("note", moyenneUE);
                ueDetails.put("valide", valide);
                ueDetails.put("appreciation", appreciation);
                ueDetails.put("semestre", semestre);

                // Ajouter les détails de l'UE à la liste
                ueDetailsList.add(ueDetails);
            }

            // Calculer la moyenne du semestre
            moyenneSemestre = notesService.calculerMoyenneSemestre(notesSemestre);
            moyenneNiveau += moyenneSemestre;
            totalSemestres++;


            // Ajouter les détails du semestre à la map
            Map<String, Object> semestreDetails = new HashMap<>();
            semestreDetails.put("ueDetails", ueDetailsList);
            semestreDetails.put("moyenneSemestre", moyenneSemestre);
            semestreDetails.put("creditsValides", creditsValides);
            semestreDetails.put("totalCredits", totalCreditsSemestre);

            ueDetailsBySemestre.put(semestre, semestreDetails);
        }

        // Calculer la moyenne globale du niveau
        moyenneNiveau = (totalSemestres > 0) ? (moyenneNiveau / totalSemestres) : 0.0;
        String mention = notesService.AppreciMoyenne(moyenneNiveau);
        // Préparer la réponse
        Map<String, Object> response = new HashMap<>();
        response.put("ueDetailsBySemestre", ueDetailsBySemestre);
        response.put("moyenneNiveau", moyenneNiveau);
        response.put("mention", mention);

        return response;
    }

}
//        List<Note> notes = new ArrayList<>();
//        for (TypeSemestre semestre : semestresAssocies) {
//            notes.addAll(noteRepository.findByEtudiantAndTypeSemestre(etudiant, semestre));
//        }
