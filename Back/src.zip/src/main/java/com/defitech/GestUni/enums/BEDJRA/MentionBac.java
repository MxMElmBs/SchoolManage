package com.defitech.GestUni.enums.BEDJRA;

public enum MentionBac {
    PASSABLE, ASSEZ_BIEN, BIEN, TRES_BIEN

}
