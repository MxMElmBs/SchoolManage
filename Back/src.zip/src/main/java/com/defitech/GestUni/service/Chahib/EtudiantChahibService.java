package com.defitech.GestUni.service.Chahib;

import com.defitech.GestUni.dto.EtudiantDetailsDto;
import com.defitech.GestUni.models.Bases.Etudiant;
import com.defitech.GestUni.models.Bases.Professeur;
import com.defitech.GestUni.models.Chahib.Document;
import com.defitech.GestUni.repository.DocumentRepository;
import com.defitech.GestUni.repository.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class EtudiantChahibService {

    @Autowired
    private EtudiantRepository etudiantRepository;

    @Autowired
    private DocumentRepository documentRepository;

    // Méthode pour récupérer les détails d'un étudiant à partir de l'ID du document
    public Optional<EtudiantDetailsDto> getEtudiantDetailsByDocumentId(Long documentId) {
        // Trouver le document par ID
        Optional<Document> documentOpt = documentRepository.findById(documentId);
        if (documentOpt.isPresent()) {
            Document document = documentOpt.get();
            Etudiant etudiant = document.getEtudiant();  // Récupérer l'étudiant associé au document

            // Créer un DTO pour rassembler toutes les informations nécessaires
            EtudiantDetailsDto detailsDto = new EtudiantDetailsDto();
            detailsDto.setNom(etudiant.getNom());
            detailsDto.setPrenom(etudiant.getPrenom());
            detailsDto.setParcours(document.getParcours().getNomParcours());
            detailsDto.setFiliere(document.getFiliere().getNomFiliere());
            detailsDto.setTheme(document.getTheme());
            detailsDto.setTypeDocument(document.getTypeDocument().name());
            detailsDto.setDocumentUrl(document.getDocumentUrl());  // Ajout de l'URL du document

            // Extraire l'année du champ createdAt
            LocalDateTime createdAt = document.getCreatedAt();
            int annee = createdAt.getYear();  // Extraire uniquement l'année
            detailsDto.setAnnee(annee);  // Définir l'année dans le DTO

            // Ajouter les informations sur le professeur si elles sont présentes
            Professeur professeur = document.getProfesseur();
            if (professeur != null) {
                detailsDto.setProfesseurNom(professeur.getNom());
                detailsDto.setProfesseurPrenom(professeur.getPrenom());
            }

            return Optional.of(detailsDto);
        }
        return Optional.empty();  // Si le document n'est pas trouvé
    }
}
