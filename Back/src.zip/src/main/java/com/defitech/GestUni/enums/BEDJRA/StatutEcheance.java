package com.defitech.GestUni.enums.BEDJRA;

import java.util.List;

public enum StatutEcheance {
     PAYEE , PARTIELLEMENT_PAYEE, EN_ATTENTE;
}
