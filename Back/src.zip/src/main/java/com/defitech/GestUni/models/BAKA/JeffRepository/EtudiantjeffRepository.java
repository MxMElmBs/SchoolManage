package com.defitech.GestUni.models.BAKA.JeffRepository;

import com.defitech.GestUni.enums.NiveauEtude;
import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.Bases.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EtudiantjeffRepository extends JpaRepository<Etudiant, Long> {

//    @Query("SELECT e FROM Etudiant e JOIN e.ue ue WHERE ue.typeSemestre = :typeSemestre")
//    List<Etudiant> findEtudiantsByTypeSemestre(@Param("typeSemestre") TypeSemestre typeSemestre);
      List<Etudiant> findEtudiantsByTypeSemestre(TypeSemestre typeSemestre);
      @Query("SELECT DISTINCT n.etudiant FROM Note n")
      List<Etudiant> findEtudiantsWithNotes();
      List<Etudiant> findByNiveauEtude(NiveauEtude niveauEtude);
}
