package com.defitech.GestUni.models.BAKA.JeffRepository;

import com.defitech.GestUni.enums.TypeSemestre;
import com.defitech.GestUni.models.Bases.UE;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UejeffRepository extends JpaRepository<UE, Long> {


    @Query("SELECT ue FROM UE ue WHERE ue.typeSemestre = :typeSemestre")
    List<UE> findByTypeSemestre(@Param("typeSemestre") TypeSemestre typeSemestre);

    @Query("SELECT ue FROM UE ue JOIN Note n ON n.ue = ue WHERE ue.typeSemestre = :typeSemestre GROUP BY ue")
    List<UE> findUesWithNotesBySemestre(@Param("typeSemestre") TypeSemestre typeSemestre);

}
