package com.defitech.GestUni.enums.BEDJRA;

public enum TypeModalite {
    TOTALITE,
    TROIS_TRANCHES,
    SEPT_TRANCHES,

}
