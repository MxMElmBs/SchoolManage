package com.defitech.GestUni.models.Chahib;


public enum TypeDocument {
     Tutore, Memoire
}
