import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router'; // Import du RouterModule

interface UEData {
  ueId: number;
  libelle: string;
  code: string;
  credit: number;
  professeurNom: string;
}

@Component({
  selector: 'app-matiere',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, RouterModule], // Ajout de RouterModule
  templateUrl: './matiere.component.html',
  styleUrls: ['./matiere.component.css']
})
export class MatiereComponent implements OnInit {
  dataSource2: UEData[] = [];
  filteredData: UEData[] = [];

  filter = {
    nom: '',
    code: '',
    chargecours: ''
  };

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getUEData();
  }

  // Méthode pour appeler l'API et récupérer les UE par parcours
  getUEData(): void {
    const parcoursId = 1; // Par exemple: remplacer par l'ID de parcours nécessaire
    const apiUrl = `http://localhost:8060/api/auth/de/ueParparcours/${parcoursId}`; // URL de l'API

    this.http.get<UEData[]>(apiUrl).subscribe((response) => {
      this.dataSource2 = response;
      this.filteredData = [...this.dataSource2]; // Copier les données pour filtrage
    }, (error) => {
      console.error('Erreur lors de la récupération des données de l\'API', error);
    });
  }

  // Méthode de filtrage
  onFilterChange(): void {
    this.filteredData = this.dataSource2.filter(item => {
      const matchesNom = item.libelle.toLowerCase().includes(this.filter.nom.toLowerCase());
      const matchesCode = item.code.toLowerCase().includes(this.filter.code.toLowerCase());
      const matchesChargeCours = item.professeurNom.toLowerCase().includes(this.filter.chargecours.toLowerCase());

      return matchesNom && matchesCode && matchesChargeCours;
    });
  }

  view() {
    console.log('View button clicked');
  }

  delete() {
    console.log('Delete button clicked');
  }
}
