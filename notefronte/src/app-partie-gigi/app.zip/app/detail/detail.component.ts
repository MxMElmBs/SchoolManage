import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

interface cours {
  ueId: number;
  libelle: string;
  code: string;
  credit: number;
  descriptUe: string;
  typeUe: string;
  niveauEtude: string;
  typeSemestre: string;
  professeurNom: string;
  parcoursNom: string | null;
  filiereNom: string[]; // Tableau de filières
}

@Component({
  selector: 'app-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  cours: cours | undefined;

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.getCoursById(id);
    }
  }

  getCoursById(id: string): void {
    const apiUrl = `http://localhost:8060/api/auth/de/uebyId/${id}`;
    this.http.get<cours>(apiUrl).subscribe(
      (response) => {
        this.cours = response;
      },
      (error) => {
        console.error('Erreur lors de la récupération des détails du cours', error);
      }
    );
  }
}
