import { Component } from '@angular/core';

@Component({
  selector: 'app-listecours',
  standalone: true,
  imports: [],
  templateUrl: './listecours.component.html',
  styleUrl: './listecours.component.css'
})
export class ListecoursComponent {

}
