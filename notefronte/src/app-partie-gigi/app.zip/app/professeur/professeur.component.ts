import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgOptimizedImage } from '@angular/common';

@Component({
  selector: 'app-professeur',
  standalone: true,
  imports: [RouterOutlet,CommonModule,MatSidenavModule, RouterLink , MatSnackBarModule, NgOptimizedImage],
  templateUrl: './professeur.component.html',
  styleUrl: './professeur.component.css'
})
export class ProfesseurComponent implements OnInit {
  search() {
    // Implement search logic here
    console.log('Search clicked');
  }

  constructor(private router: Router) {}


  data: string | null = null;  

  ngOnInit() {  
    // Simuler une récupération de données avec un délai  
    setTimeout(() => {  
      this.data = "PINDRA Nadjime";  
    }, 3000); // Simule un délai de 3 secondes 
    
    
  }  

  get content() {  
    return this.data;  
  } 
}
