import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';

interface Seance {
  date: Date;
  heureDebut: string;
  heureFin: string;
  contenu: string;
} 
@Component({
  selector: 'app-resumecahier',
  standalone: true,
  imports: [CommonModule,  MatTableModule,
    MatCardModule,
    MatIconModule,
    MatGridListModule],
  templateUrl: './resumecahier.component.html',
  styleUrl: './resumecahier.component.css'
})
export class ResumecahierComponent {
    // Exemple de données pour les séances
    historiqueSeances: Seance[] = [
      {
        date: new Date('2024-01-12'),
        heureDebut: '09:00',
        heureFin: '11:00',
        contenu: 'Introduction à Angular'
      },
      {
        date: new Date('2024-01-15'),
        heureDebut: '14:00',
        heureFin: '16:00',
        contenu: 'Les composants Angular'
      },
  
      
      // Ajouter d'autres séances ici...
    ];
  
    displayedColumns: string[] = ['date', 'heureDebut', 'heureFin', 'duree', 'contenu'];
  
    // Calcul du nombre total de séances
    getTotalSeances(): number {
      return this.historiqueSeances.length;
    }
  
    // Calcul du nombre total d'heures effectuées
    getTotalHours(): number {
      let totalMinutes = 0;
      this.historiqueSeances.forEach(seance => {
        totalMinutes += this.getDureeEnMinutes(seance.heureDebut, seance.heureFin);
      });
      return totalMinutes / 60;
    }
  
    // Calcul du pourcentage d'achèvement du cours
    getCompletionPercentage(): number {
      const totalHeures = this.getTotalHours();
      const totalHeuresCours = 100; // Durée totale prévue du cours en heures
      return Math.min((totalHeures / totalHeuresCours) * 100, 100);
    }
  
    // Calcul de la durée entre heure de début et heure de fin
    getDuree(heureDebut: string, heureFin: string): string {
      const dureeMinutes = this.getDureeEnMinutes(heureDebut, heureFin);
      const heures = Math.floor(dureeMinutes / 60);
      const minutes = dureeMinutes % 60;
      return `${heures}h ${minutes}min`;
    }
  
    // Calcul de la durée en minutes
    getDureeEnMinutes(heureDebut: string, heureFin: string): number {
      const [heureDebutHeures, heureDebutMinutes] = heureDebut.split(':').map(Number);
      const [heureFinHeures, heureFinMinutes] = heureFin.split(':').map(Number);
      const debut = heureDebutHeures * 60 + heureDebutMinutes;
      const fin = heureFinHeures * 60 + heureFinMinutes;
      return fin - debut;
    }
  notifierProfesseur(cours: string) {  
    alert(`Le professeur a été notifié que le cours ${cours} est en retard.`);  
  } 
}
