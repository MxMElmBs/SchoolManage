import { Component, OnInit } from '@angular/core';  
import { Chart, registerables } from 'chart.js';  

Chart.register(...registerables);  

@Component({  
  selector: 'app-volume-horaire',  
  templateUrl: './volume-horaire.component.html',  
  styleUrls: ['./volume-horaire.component.css']  
})  
export class VolumeHoraireComponent implements OnInit {  

  // Définir les données  
  public chart: any;  
  public volumesHoraires: number[] = [10, 15, 25, 5, 20]; // Données de volumes horaires par UE  
  public seuil: number = 10; // Seuil horaire  
  public nomsProfesseurs: string[] = ['Prof A', 'Prof B', 'Prof C', 'Prof D', 'Prof E']; // Pour les UEs  

  ngOnInit(): void {  
    this.createChart();  
  }  

  createChart() {  
    this.chart = new Chart('canvas', {  
      type: 'bar', // ou 'line', 'pie' selon vos besoins  
      data: {  
        labels: this.nomsProfesseurs,  
        datasets: [{  
          label: 'Volumes Horaires Hebdomadaires',  
          data: this.volumesHoraires,  
          backgroundColor: this.volumesHoraires.map(volume => volume < this.seuil ? 'rgba(255, 99, 132, 0.6)' : 'rgba(75, 192, 192, 0.6)'),  
          borderColor: 'rgba(255, 99, 132, 1)',  
          borderWidth: 1 
           
        }]  
      },  
      options: {  
        scales: {  
          y: {  
            beginAtZero: true  
          }  
        }  
      }  
    });  
  }  
}
