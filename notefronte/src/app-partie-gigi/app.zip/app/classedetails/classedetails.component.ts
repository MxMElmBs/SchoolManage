import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCard } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

// presence.model.ts
export interface Etudiant {
  matricule: string;
  nom: string;
  prenom: string;
  tauxAbsence: number;
}

@Component({
  selector: 'app-classedetails',
  standalone: true,
  imports: [CommonModule, MatCard, MatTableModule],
  templateUrl: './classedetails.component.html',
  styleUrl: './classedetails.component.css'
})
export class ClassedetailsComponent {
  etudiants: Etudiant[] = [
    { matricule: '12345', nom: 'Dupont', prenom: 'Jean', tauxAbsence: 10 },
    { matricule: '67890', nom: 'Doe', prenom: 'John', tauxAbsence: 20 },
    // Ajoute d'autres étudiants ici
  ];

  displayedColumns: string[] = ['matricule', 'nom', 'prenom', 'tauxAbsence', 'action'];

  signalerAbsence(etudiant: Etudiant) {
    // Logique pour signaler une absence
    console.log('Absence signalée pour', etudiant);
  }
}
