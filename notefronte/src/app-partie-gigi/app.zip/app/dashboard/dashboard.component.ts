import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgOptimizedImage } from '@angular/common';
import {MatBadgeModule} from '@angular/material/badge';



@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterOutlet,CommonModule,MatSidenavModule, RouterLink , MatSnackBarModule, NgOptimizedImage, MatBadgeModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent {
  search() {
    // Implement search logic here
    console.log('Search clicked');
  }

  constructor(private router: Router) {}

  onItemClick(route: string): void {
    this.router.navigate([route]);
  }

    isActive(route: string): boolean {
    return this.router.url === route;
  }
  studentsMenuOpen = false; // Assurez-vous que cette variable existe

  toggleStudentsMenu() {
    // Inverser l'état du menu, si vous voulez le basculer par clic
    this.studentsMenuOpen = !this.studentsMenuOpen;
  }

  onSubmenuItemClick() {
    // Laissez le menu ouvert
    this.studentsMenuOpen = true; // Force le menu à rester ouvert
  }
  logout(){
    this.router.navigate(['/login'])
  }

  hidden = false;

  toggleBadgeVisibility() {
    this.hidden = !this.hidden;
  }
}
