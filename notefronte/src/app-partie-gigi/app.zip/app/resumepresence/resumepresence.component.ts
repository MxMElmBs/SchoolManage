import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCommonModule } from '@angular/material/core';
import { CommonModule } from '@angular/common';
import { routes } from '../app.routes';
import { Router } from '@angular/router';

// presence.model.ts
export interface Seance {
  date: Date;
  presences: Presence[];
}

export interface Presence {
  matricule: string;
  nom: string;
  prenom: string;
  present: boolean;
}

export interface Etudiant {
  matricule: string;
  nom: string;
  prenom: string;
  tauxAbsence: number;
}


@Component({
  selector: 'app-resumepresence',
  standalone: true,
  imports: [MatCommonModule, MatCardModule, MatTableModule,MatGridListModule, MatIconModule, CommonModule,routes],
  templateUrl: './resumepresence.component.html',
  styleUrl: './resumepresence.component.css'
})
export class ResumepresenceComponent {
  seances: Seance[] = [
    {
      date: new Date('2024-09-19'),
      presences: [
        { matricule: '12345', nom: 'Dupont', prenom: 'Jean', present: true },
        { matricule: '67890', nom: 'Doe', prenom: 'John', present: false },
        // Ajoute d'autres étudiants ici
      ]
    },
    {
      date: new Date('2024-09-18'),
      presences: [
        { matricule: '12345', nom: 'Dupont', prenom: 'Jean', present: true },
        { matricule: '67890', nom: 'Doe', prenom: 'John', present: true },
        // Ajoute d'autres étudiants ici
      ]
    }
  ];

  displayedColumns: string[] = ['matricule', 'nom', 'prenom', 'present'];

  getTauxPresence(): number {
    const totalPresences = this.seances.reduce((sum, seance) => 
      sum + seance.presences.filter(presence => presence.present).length, 0);
    const totalEtudiants = this.seances.reduce((sum, seance) => sum + seance.presences.length, 0);
    return totalEtudiants > 0 ? (totalPresences / totalEtudiants) * 100 : 0;
  }

  getNombreAbsents(): number {
    return this.seances.reduce((sum, seance) => sum + seance.presences.filter(presence => !presence.present).length, 0);
  }
  constructor(private router: Router) {}


  goToDetails() {
    // Naviguer vers la page des détails de la classe
    this.router.navigate(['/app-gigi/classedetails']);
  }
}
