import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgOptimizedImage } from '@angular/common';

@Component({
  selector: 'app-studentdash',
  standalone: true,
  imports: [RouterOutlet,CommonModule,MatSidenavModule, RouterLink , MatSnackBarModule, NgOptimizedImage],
  templateUrl: './studentdash.component.html',
  styleUrl: './studentdash.component.css'
})
export class StudentdashComponent {
  search() {
    // Implement search logic here
    console.log('Search clicked');
  }

  constructor(private router: Router) {}

  onItemClick(route: string): void {
    this.router.navigate([route]);
  }

    isActive(route: string): boolean {  
    return this.router.url === route;  
  }  
}
